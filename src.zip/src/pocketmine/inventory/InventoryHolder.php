<?php

namespace pocketmine\inventory;

interface InventoryHolder{

 public function getInventory();
}