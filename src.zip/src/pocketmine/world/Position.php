<?php

namespace pocketmine\world;

use pocketmine\level\Position as OriginalPosition;

class Position extends OriginalPosition{}