<?php

namespace pocketmine\world;

use pocketmine\level\Level as OriginalLevel;

class World extends OriginalLevel{}