<?php

namespace pocketmine\player;

class GameMode{

 public static function Creative() : int{
  return 1;
 }
 public static function Survival() : int{
  return 0;
 }
}